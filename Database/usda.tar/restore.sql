--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 11.2
-- Dumped by pg_dump version 11.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE usda;
--
-- Name: usda; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE usda WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE usda OWNER TO postgres;

\connect usda

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: data_src; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.data_src (
    datasrc_id character(6) NOT NULL,
    authors text,
    title text NOT NULL,
    year integer,
    journal text,
    vol_city text,
    issue_state text,
    start_page text,
    end_page text
);


ALTER TABLE public.data_src OWNER TO postgres;

--
-- Name: datsrcln; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.datsrcln (
    ndb_no character(5) NOT NULL,
    nutr_no character(3) NOT NULL,
    datasrc_id character(6) NOT NULL
);


ALTER TABLE public.datsrcln OWNER TO postgres;

--
-- Name: deriv_cd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deriv_cd (
    deriv_cd text NOT NULL,
    derivcd_desc text NOT NULL
);


ALTER TABLE public.deriv_cd OWNER TO postgres;

--
-- Name: fd_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.fd_group (
    fdgrp_cd character(4) NOT NULL,
    fddrp_desc text NOT NULL
);


ALTER TABLE public.fd_group OWNER TO postgres;

--
-- Name: food_des; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.food_des (
    ndb_no character(5) NOT NULL,
    fdgrp_cd character(4) NOT NULL,
    long_desc text NOT NULL,
    shrt_desc text NOT NULL,
    comname text,
    manufacname text,
    survey character(1),
    ref_desc text,
    refuse integer,
    sciname text,
    n_factor double precision,
    pro_factor double precision,
    fat_factor double precision,
    cho_factor double precision
);


ALTER TABLE public.food_des OWNER TO postgres;

--
-- Name: footnote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.footnote (
    ndb_no character(5) NOT NULL,
    footnt_no character(4) NOT NULL,
    footnt_typ character(1) NOT NULL,
    nutr_no character(3),
    footnt_txt text NOT NULL
);


ALTER TABLE public.footnote OWNER TO postgres;

--
-- Name: nut_data; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nut_data (
    ndb_no character(5) NOT NULL,
    nutr_no character(3) NOT NULL,
    nutr_val double precision NOT NULL,
    num_data_pts double precision NOT NULL,
    std_error double precision,
    src_cd integer NOT NULL,
    deriv_cd text,
    ref_ndb_no character(5),
    add_nutr_mark character(1),
    num_studies integer,
    min double precision,
    max double precision,
    df integer,
    low_eb double precision,
    up_eb double precision,
    stat_cmt text,
    cc character(1)
);


ALTER TABLE public.nut_data OWNER TO postgres;

--
-- Name: nutr_def; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.nutr_def (
    nutr_no character(3) NOT NULL,
    units text NOT NULL,
    tagname text,
    nutrdesc text,
    num_dec smallint,
    sr_order integer
);


ALTER TABLE public.nutr_def OWNER TO postgres;

--
-- Name: src_cd; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.src_cd (
    src_cd integer NOT NULL,
    srccd_desc text NOT NULL
);


ALTER TABLE public.src_cd OWNER TO postgres;

--
-- Name: weight; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.weight (
    ndb_no character(5) NOT NULL,
    seq character(2) NOT NULL,
    amount double precision NOT NULL,
    msre_desc text NOT NULL,
    gm_wgt double precision NOT NULL,
    num_data_pts integer,
    std_dev double precision
);


ALTER TABLE public.weight OWNER TO postgres;

--
-- Data for Name: data_src; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.data_src (datasrc_id, authors, title, year, journal, vol_city, issue_state, start_page, end_page) FROM stdin;
\.
COPY public.data_src (datasrc_id, authors, title, year, journal, vol_city, issue_state, start_page, end_page) FROM '$$PATH$$/3200.dat';

--
-- Data for Name: datsrcln; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.datsrcln (ndb_no, nutr_no, datasrc_id) FROM stdin;
\.
COPY public.datsrcln (ndb_no, nutr_no, datasrc_id) FROM '$$PATH$$/3201.dat';

--
-- Data for Name: deriv_cd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deriv_cd (deriv_cd, derivcd_desc) FROM stdin;
\.
COPY public.deriv_cd (deriv_cd, derivcd_desc) FROM '$$PATH$$/3202.dat';

--
-- Data for Name: fd_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.fd_group (fdgrp_cd, fddrp_desc) FROM stdin;
\.
COPY public.fd_group (fdgrp_cd, fddrp_desc) FROM '$$PATH$$/3203.dat';

--
-- Data for Name: food_des; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.food_des (ndb_no, fdgrp_cd, long_desc, shrt_desc, comname, manufacname, survey, ref_desc, refuse, sciname, n_factor, pro_factor, fat_factor, cho_factor) FROM stdin;
\.
COPY public.food_des (ndb_no, fdgrp_cd, long_desc, shrt_desc, comname, manufacname, survey, ref_desc, refuse, sciname, n_factor, pro_factor, fat_factor, cho_factor) FROM '$$PATH$$/3204.dat';

--
-- Data for Name: footnote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.footnote (ndb_no, footnt_no, footnt_typ, nutr_no, footnt_txt) FROM stdin;
\.
COPY public.footnote (ndb_no, footnt_no, footnt_typ, nutr_no, footnt_txt) FROM '$$PATH$$/3205.dat';

--
-- Data for Name: nut_data; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nut_data (ndb_no, nutr_no, nutr_val, num_data_pts, std_error, src_cd, deriv_cd, ref_ndb_no, add_nutr_mark, num_studies, min, max, df, low_eb, up_eb, stat_cmt, cc) FROM stdin;
\.
COPY public.nut_data (ndb_no, nutr_no, nutr_val, num_data_pts, std_error, src_cd, deriv_cd, ref_ndb_no, add_nutr_mark, num_studies, min, max, df, low_eb, up_eb, stat_cmt, cc) FROM '$$PATH$$/3206.dat';

--
-- Data for Name: nutr_def; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.nutr_def (nutr_no, units, tagname, nutrdesc, num_dec, sr_order) FROM stdin;
\.
COPY public.nutr_def (nutr_no, units, tagname, nutrdesc, num_dec, sr_order) FROM '$$PATH$$/3207.dat';

--
-- Data for Name: src_cd; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.src_cd (src_cd, srccd_desc) FROM stdin;
\.
COPY public.src_cd (src_cd, srccd_desc) FROM '$$PATH$$/3208.dat';

--
-- Data for Name: weight; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.weight (ndb_no, seq, amount, msre_desc, gm_wgt, num_data_pts, std_dev) FROM stdin;
\.
COPY public.weight (ndb_no, seq, amount, msre_desc, gm_wgt, num_data_pts, std_dev) FROM '$$PATH$$/3209.dat';

--
-- Name: data_src data_src_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.data_src
    ADD CONSTRAINT data_src_pkey PRIMARY KEY (datasrc_id);


--
-- Name: datsrcln datsrcln_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.datsrcln
    ADD CONSTRAINT datsrcln_pkey PRIMARY KEY (ndb_no, nutr_no, datasrc_id);


--
-- Name: deriv_cd deriv_cd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deriv_cd
    ADD CONSTRAINT deriv_cd_pkey PRIMARY KEY (deriv_cd);


--
-- Name: fd_group fd_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.fd_group
    ADD CONSTRAINT fd_group_pkey PRIMARY KEY (fdgrp_cd);


--
-- Name: food_des food_des_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_des
    ADD CONSTRAINT food_des_pkey PRIMARY KEY (ndb_no);


--
-- Name: nut_data nut_data_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nut_data
    ADD CONSTRAINT nut_data_pkey PRIMARY KEY (ndb_no, nutr_no);


--
-- Name: nutr_def nutr_def_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nutr_def
    ADD CONSTRAINT nutr_def_pkey PRIMARY KEY (nutr_no);


--
-- Name: src_cd src_cd_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.src_cd
    ADD CONSTRAINT src_cd_pkey PRIMARY KEY (src_cd);


--
-- Name: weight weight_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weight
    ADD CONSTRAINT weight_pkey PRIMARY KEY (ndb_no, seq);


--
-- Name: datsrcln_datasrc_id_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX datsrcln_datasrc_id_idx ON public.datsrcln USING btree (datasrc_id);


--
-- Name: food_des_fdgrp_cd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX food_des_fdgrp_cd_idx ON public.food_des USING btree (fdgrp_cd);


--
-- Name: footnote_ndb_no_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX footnote_ndb_no_idx ON public.footnote USING btree (ndb_no, nutr_no);


--
-- Name: nut_data_deriv_cd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nut_data_deriv_cd_idx ON public.nut_data USING btree (deriv_cd);


--
-- Name: nut_data_nutr_no_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nut_data_nutr_no_idx ON public.nut_data USING btree (nutr_no);


--
-- Name: nut_data_src_cd_idx; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX nut_data_src_cd_idx ON public.nut_data USING btree (src_cd);


--
-- Name: datsrcln datsrcln_datasrc_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.datsrcln
    ADD CONSTRAINT datsrcln_datasrc_id_fkey FOREIGN KEY (datasrc_id) REFERENCES public.data_src(datasrc_id);


--
-- Name: datsrcln datsrcln_ndb_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.datsrcln
    ADD CONSTRAINT datsrcln_ndb_no_fkey FOREIGN KEY (ndb_no, nutr_no) REFERENCES public.nut_data(ndb_no, nutr_no);


--
-- Name: food_des food_des_fdgrp_cd_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.food_des
    ADD CONSTRAINT food_des_fdgrp_cd_fkey FOREIGN KEY (fdgrp_cd) REFERENCES public.fd_group(fdgrp_cd);


--
-- Name: footnote footnote_ndb_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.footnote
    ADD CONSTRAINT footnote_ndb_no_fkey FOREIGN KEY (ndb_no) REFERENCES public.food_des(ndb_no);


--
-- Name: footnote footnote_nutr_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.footnote
    ADD CONSTRAINT footnote_nutr_no_fkey FOREIGN KEY (nutr_no) REFERENCES public.nutr_def(nutr_no);


--
-- Name: nut_data nut_data_deriv_cd_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nut_data
    ADD CONSTRAINT nut_data_deriv_cd_fkey FOREIGN KEY (deriv_cd) REFERENCES public.deriv_cd(deriv_cd);


--
-- Name: nut_data nut_data_ndb_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nut_data
    ADD CONSTRAINT nut_data_ndb_no_fkey FOREIGN KEY (ndb_no) REFERENCES public.food_des(ndb_no);


--
-- Name: nut_data nut_data_nutr_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nut_data
    ADD CONSTRAINT nut_data_nutr_no_fkey FOREIGN KEY (nutr_no) REFERENCES public.nutr_def(nutr_no);


--
-- Name: nut_data nut_data_src_cd_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.nut_data
    ADD CONSTRAINT nut_data_src_cd_fkey FOREIGN KEY (src_cd) REFERENCES public.src_cd(src_cd);


--
-- Name: weight weight_ndb_no_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.weight
    ADD CONSTRAINT weight_ndb_no_fkey FOREIGN KEY (ndb_no) REFERENCES public.food_des(ndb_no);


--
-- PostgreSQL database dump complete
--

